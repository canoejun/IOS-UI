//
//  AppDelegate.h
//  UITextField接收输入
//
//  Created by PengXiaodong on 2018/8/7.
//  Copyright © 2018年 PengXiaodong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

