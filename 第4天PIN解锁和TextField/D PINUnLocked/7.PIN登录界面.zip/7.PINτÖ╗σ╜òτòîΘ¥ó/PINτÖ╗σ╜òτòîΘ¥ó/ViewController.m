//
//  ViewController.m
//  PIN登录界面
//
//  Created by PengXiaodong on 2018/8/8.
//  Copyright © 2018年 PengXiaodong. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UITextFieldDelegate>
@property (nonatomic, strong) UILabel *alertLabel;
@property (nonatomic, strong) UITextField *pwdTextFiled;
@property (nonatomic, assign) BOOL isLogin;
@property (nonatomic, strong) NSString *firstInputPwdString;
@property (nonatomic, strong) NSString *password;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.password = @"123";
    
    //设置没有设置过密码
    self.isLogin = NO;
    
    //创建UILabel
    self.alertLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 100, self.view.frame.size.width, 60)];
    _alertLabel.textAlignment = NSTextAlignmentCenter;
    _alertLabel.font = [UIFont systemFontOfSize:20];
    [self.view addSubview:_alertLabel];
    
    //判断显示的内容
    if (_isLogin == NO){
        //设置密码
        self.alertLabel.text = @"请设置密码";
    } else{
        //解锁密码
        self.alertLabel.text = @"请输入解锁密码";
    }
    
    //创建UITextField
    self.pwdTextFiled = [[UITextField alloc] initWithFrame:CGRectMake(20, 210, self.view.frame.size.width-20-20, 60)];
    _pwdTextFiled.placeholder = @"密码";
    _pwdTextFiled.borderStyle = UITextBorderStyleLine;
    _pwdTextFiled.secureTextEntry = YES;
    _pwdTextFiled.delegate = self;
    [self.view addSubview:_pwdTextFiled];
    
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    //弹出键盘
    [self.pwdTextFiled becomeFirstResponder];
}

//响应键盘的return按钮被点击的事件
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self.pwdTextFiled resignFirstResponder];
    
    //1.确认密码  2.比较密码
    if (_isLogin == YES){
        //登录过了 只需要比较一下和原来的密码是否相同
        if ([_pwdTextFiled.text isEqualToString:_password]){
            //正确
            self.alertLabel.text = @"密码正确 即将跳转";
        } else{
            //不正确
            self.alertLabel.textColor = [UIColor redColor];
            self.alertLabel.text = @"密码不正确 请重新输入";
        }
    } else{
        //设置密码
        //第一次输入密码 第二次输入密码
        if (_firstInputPwdString.length == 0){
            //第一次输入密码
            //保存这一次的密码
            self.firstInputPwdString = self.pwdTextFiled.text;
            //提示请确认密码
            self.alertLabel.text = @"请确认密码";
        } else{
            //第二次确认密码的时候进来
            if ([self.firstInputPwdString isEqualToString:_pwdTextFiled.text]){
                self.alertLabel.text = @"密码设置正确";
                //跳转到主页
            }else{
                //密码不正确
                self.alertLabel.text = @"两次密码不一致 请重新设置";
                _alertLabel.textColor = [UIColor redColor];
                
                //清空保存第一次的密码
                self.firstInputPwdString = @"";
            }
        }
    }
    
    self.pwdTextFiled.text = @"";
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField{
    self.alertLabel.textColor = [UIColor blackColor];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    //将string拼接到原来的内容上 得到即将显示的新的文本
    NSString *newStr = [_pwdTextFiled.text stringByReplacingCharactersInRange:range withString:string];
    
    if (newStr.length == 7) {
        return NO;
    }
    return YES;
}
@end

















