//
//  ViewController.m
//  主题切换
//
//  Created by PengXiaodong on 2018/8/9.
//  Copyright © 2018年 PengXiaodong. All rights reserved.
//

#import "ViewController.h"
#import "ThemeImageView.h"
#import "ThemeManager.h"
#import "Constants.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    ThemeImageView *v1 = [[ThemeImageView alloc] initWithFrame:CGRectMake(50, 200, 100, 50)];
    v1.imageName = @"1.png";
    [self.view addSubview:v1];
    
    ThemeImageView *v2 = [[ThemeImageView alloc] initWithFrame:CGRectMake(200, 200, 100, 50)];
    v2.imageName = @"2.png";
    [self.view addSubview:v2];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    //切换主题
    //1.改变Thememanager里面的themeName
    [ThemeManager sharedInstance].themeName = @"黑色";
    
    //2.发通知
    [[NSNotificationCenter defaultCenter] postNotificationName:kThemeDidChangeNotificationName object:nil];
}
@end







