//
//  Constants.h
//  主题切换
//
//  Created by PengXiaodong on 2018/8/9.
//  Copyright © 2018年 PengXiaodong. All rights reserved.
//

#ifndef Constants_h
#define Constants_h

//主题切换的消息名
#define kThemeDidChangeNotificationName @"kThemeDidChangeNotificationName"

#endif /* Constants_h */









