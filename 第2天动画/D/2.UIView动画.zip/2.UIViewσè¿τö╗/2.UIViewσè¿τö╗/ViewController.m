//
//  ViewController.m
//  2.UIView动画
//
//  Created by PengXiaodong on 2018/8/4.
//  Copyright © 2018年 PengXiaodong. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (nonatomic, strong) UIView *redView;
//@property (nonatomic, copy) void(^block)(void);
@end

@implementation ViewController
//- (void)dealloc{
//    Block_release(_block);
//
//    [super dealloc];
//}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //创建一个UIView
    self.redView = [[UIView alloc] initWithFrame:CGRectMake(150, 400, 100, 100)];
    _redView.backgroundColor = [UIColor redColor];
    [self.view addSubview:_redView];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    //[self test1];
}

/*
 渐变 alpha 0全透明  1不透明
 */
- (void)test1{
    //现将初始状态改为全透明
    //_redView.alpha = 0;
    
    //使用block动画
//    void (^block)(void) = ^{
//        self.redView.alpha = 1;
//    };
//    [UIView animateWithDuration:1 animations:block];
    [UIView animateWithDuration:1 animations:^{
        self.redView.alpha = 0;
    }];
}

//frame移动
- (void)test2{
    [UIView animateWithDuration:1 animations:^{
        //放大 width height
        //self.redView.frame = CGRectMake(150, 200, 100*0.5, 100*0.5);
        
        //移动 150 200 100 100
        self.redView.center = CGPointMake(self.redView.center.x , self.redView.center.y - 150);
    }];
}

//
- (void)test3{
    self.redView.alpha = 1;
    
    //开始动画设置
    [UIView beginAnimations:nil context:nil];
    //设置动画的时间
    [UIView setAnimationDuration:2];
    //设置代理
    [UIView setAnimationDelegate:self];
    //动画效果的节奏为满进慢出
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    
    [UIView setAnimationRepeatAutoreverses:NO];
    
    //设置具体的动画
    [UIView setAnimationTransition:UIViewAnimationTransitionCurlUp forView:self.redView cache:NO];
    //要干什么
    //删除红色的视图
    self.redView.alpha = 0;
    //提交动画
    [UIView commitAnimations];
}

-(void)animationDidStop:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context{
    //[self.redView removeFromSuperview];
}

- (void)test4{
    //弹簧效果
    [UIView animateWithDuration:1 delay:0 usingSpringWithDamping:0.2 initialSpringVelocity:0.1 options:UIViewAnimationOptionCurveLinear animations:^{
        self.redView.frame = CGRectMake(150, 100, 100, 100);
        self.redView.frame = CGRectMake(150, 400, 200, 200);
    } completion:^(BOOL finished) {
        
    }];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self test4];
}
@end








