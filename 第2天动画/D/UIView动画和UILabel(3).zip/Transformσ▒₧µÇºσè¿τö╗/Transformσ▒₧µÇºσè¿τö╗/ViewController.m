//
//  ViewController.m
//  Transform属性动画
//
//  Created by PengXiaodong on 2018/8/4.
//  Copyright © 2018年 PengXiaodong. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (nonatomic, strong) UIView *redView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //frame center
    self.redView = [[UIView alloc] initWithFrame:CGRectMake(100, 200, 100, 100)];
    _redView.backgroundColor = [UIColor redColor];
    [self.view addSubview:_redView];
}

- (void)test{
    [UIView animateWithDuration:2 animations:^{
        
    }];
    
    [UIView animateWithDuration:2 animations:^{
        //具体动画的内容
    } completion:^(BOOL finished) {
        //动画完成之后的一些工作
    }];
}


- (void)test1{
    //CGAffineTransformIdentity 清楚之前所有的状态 还原到最初状态
    //make对应的方法只执行一次
    //没有make的可以执行多次
    //tx ty偏移值
    [UIView animateWithDuration:1 animations:^{
        //平移
        //self.redView.transform = CGAffineTransformMakeTranslation(100, 100);
        //self.redView.transform = CGAffineTransformTranslate(self.redView.transform, 50, 0);
        
        //缩放
        //self.redView.transform = CGAffineTransformMakeScale(2, 1);
        //self.redView.transform = CGAffineTransformScale(self.redView.transform, 0.01, 1);
        
        //旋转
        //self.redView.transform = CGAffineTransformMakeRotation(M_PI_2);
        //self.redView.transform = CGAffineTransformRotate(self.redView.transform, M_PI_2);
    }];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    /*
    [NSTimer scheduledTimerWithTimeInterval:0.01 repeats:YES block:^(NSTimer * _Nonnull timer) {
        self.redView.transform = CGAffineTransformRotate(self.redView.transform, 2/180.0*M_PI);
    }];
     */
    
    [NSTimer scheduledTimerWithTimeInterval:1 repeats:YES block:^(NSTimer * _Nonnull timer) {
        [UIView animateWithDuration:0.2 animations:^{
            self.redView.transform = CGAffineTransformScale(self.redView.transform, 1.5, 1.5);
        } completion:^(BOOL finished) {
            self.redView.transform = CGAffineTransformScale(self.redView.transform, 0.65, 0.65);
            self.redView.transform = CGAffineTransformIdentity;
        }];
        //self.redView.transform = CGAffineTransformIdentity;
    }];
    
    [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(jump) userInfo:nil repeats:YES];
}

- (void)jump{
    [UIView animateWithDuration:0.2 animations:^{
        self.redView.transform = CGAffineTransformScale(self.redView.transform, 1.5, 1.5);
    } completion:^(BOOL finished) {
        self.redView.transform = CGAffineTransformScale(self.redView.transform, 0.65, 0.65);
        self.redView.transform = CGAffineTransformIdentity;
    }];
}

@end






