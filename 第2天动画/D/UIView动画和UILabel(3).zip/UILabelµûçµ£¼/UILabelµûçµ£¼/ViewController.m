//
//  ViewController.m
//  UILabel文本
//
//  Created by PengXiaodong on 2018/8/4.
//  Copyright © 2018年 PengXiaodong. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //如何计算文本在一定情况下的具体高度和宽度
    //size: 计算的参考尺寸 必须高度或者宽度确定
    NSString *text = @"an extensive set of APIs for working with strings, including";
    //指定计算文本宽高时 所用的字体 和 字号
    NSDictionary *attrDic = @{NSFontAttributeName:[UIFont systemFontOfSize:20]};
    CGSize realSize = [text boundingRectWithSize:CGSizeMake(200, 3000) options:NSStringDrawingUsesLineFragmentOrigin attributes:attrDic context:nil].size;
    
    //创建UILabel
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(50, 50, 200, realSize.height)];
    label.backgroundColor = [UIColor grayColor];
    //设置显示的内容
    label.text = text;
    //设置字体颜色
    label.textColor = [UIColor orangeColor];
    //设置字体和字号
    label.font = [UIFont systemFontOfSize:20];
    //设置多行显示
    label.numberOfLines = 0;
    //设置换行的方式
    label.lineBreakMode = NSLineBreakByCharWrapping;
    //设置对齐方式
    label.textAlignment = NSTextAlignmentLeft;
    //添加到界面上
    [self.view addSubview:label];
    
    //设置阴影 UIView
    label.layer.shadowColor = [UIColor blackColor].CGColor;
    label.layer.shadowOffset = CGSizeMake(-20, 5);
    label.layer.shadowRadius = 5;
    label.layer.shadowOpacity = 1;
    
    
    //读取文件信息 - 路径
    //沙盒机制 程序的沙河里面
    //1.获取文件的路径
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"登山拜师" ofType:@".txt"];
    
    //2.读取文件内容
    NSString *content = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
    
    //3.计算每一页应该显示哪些内容
    //【@“第一页的内容”，@“第二页的内容”】
    //[0-100， 100-230， 231-344];
    //NSRange : location   length
    //@[NSRange, NSRange, NSRange];
    
    
    
}

@end




















