//
//  ViewController.m
//  新浪弹簧出现效果
//
//  Created by PengXiaodong on 2018/8/4.
//  Copyright © 2018年 PengXiaodong. All rights reserved.
//

#import "ViewController.h"

#define kOffset 20
#define kHeight 90
#define kWidth 90
#define kPadding ((self.view.frame.size.width-20-20-3*kWidth)*0.5)

@interface ViewController ()
@property (nonatomic, strong) NSMutableArray *itemsArray;
@property (nonatomic, strong) NSMutableArray *imageNamesArray;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //创建数组
    self.itemsArray = [NSMutableArray arrayWithCapacity:3];
    
    //创建三个视图
    for (int i = 0; i < 3; i++){
        //创建一个视图
        UIView *tempView = [[UIView alloc] initWithFrame:CGRectMake(kOffset + (kWidth + kPadding)*i, self.view.frame.size.height + 10, kWidth, kHeight)];
        tempView.layer.cornerRadius = kWidth*0.5;
        tempView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:[self.imageNamesArray objectAtIndex:i]]];
        
        [self.view addSubview:tempView];
        
        //添加到数组里面
        [self.itemsArray addObject:tempView];
    }
    
}

#pragma mark ------- 懒加载 ---------
- (NSMutableArray *)imageNamesArray{
    if (_imageNamesArray == nil) {
        self.imageNamesArray = [NSMutableArray arrayWithArray:@[@"red_Background",@"purple_Background",@"blue_Background2"]];
    }
    return _imageNamesArray;
}


#pragma mark ------- 触摸事件 ---------
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    //先获取动画的对象
    for (int i = 0; i < self.itemsArray.count; i++) {
        UIView *aview = [self.itemsArray objectAtIndex:i];
        
        [UIView animateWithDuration:2 delay:i*0.2 usingSpringWithDamping:0.5 initialSpringVelocity:0.2 options:UIViewAnimationOptionCurveLinear animations:^{
            aview.center = CGPointMake(aview.center.x, 200);
        } completion:nil];
    }
    
}


@end





