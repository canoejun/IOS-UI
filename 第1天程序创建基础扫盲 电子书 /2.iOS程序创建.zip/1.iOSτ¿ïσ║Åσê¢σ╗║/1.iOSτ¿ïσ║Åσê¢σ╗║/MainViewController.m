//
//  MainViewController.m
//  1.iOS程序创建
//
//  Created by PengXiaodong on 2018/8/3.
//  Copyright © 2018年 PengXiaodong. All rights reserved.
//

#import "MainViewController.h"
#import "SecondViewController.h"

@interface MainViewController ()
@property (nonatomic, strong) UIView *orangeView;
@property (nonatomic, strong) UIView *blackView;
@end

@implementation MainViewController

//界面如何布局
//UIViewController的执行流程
- (instancetype)init{
    self = [super init];
    
    if (self != nil) {
        NSLog(@"init");
    }
    
    return self;
}

//loadView方法
//- (void)loadView{
//    NSLog(@"load view");
//}

//viewDidLoad
- (void)viewDidLoad{
    [super viewDidLoad];
    
    //创建视图 self.view 控件与控件之间可以相互添加
    self.orangeView = [[UIView alloc] init];
    
    //设置位置和大小 frame
    _orangeView.frame = CGRectMake(50, 20+44 + 50, 200, 300);
    _orangeView.layer.cornerRadius = 150;
    
    //设置背景颜色backgroundColor
    _orangeView.backgroundColor = [UIColor orangeColor];
    
    //设置将超出显示区域的子视图 裁剪
    _orangeView.clipsToBounds = YES;
    
    //设置tag值 用来快速查找某个子视图
    _orangeView.tag = 1;
    
    //将orangeView添加到界面上(添加到self.view) addSubview
    [self.view addSubview:_orangeView];
    
    //给orangeView添加一个子视图
    UIView *redView = [[UIView alloc] init];
    redView.frame = CGRectMake(20, 20, 260, 260);
    redView.backgroundColor = [UIColor redColor];
    [_orangeView addSubview:redView];
    
    //给self.view添加一个子视图
    self.blackView = [[UIView alloc] init];
    _blackView.frame = CGRectMake(90, 150, 200, 200);
    _blackView.backgroundColor = [UIColor blackColor];
    _blackView.layer.cornerRadius = 100;
    [self.view addSubview:_blackView];
}

//viewWillAppear
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    NSLog(@"viewWillAppear");
}

//viewDidAppear
- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    NSLog(@"viewDidAppear");
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    NSLog(@"viewWillDisappear");
}

- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    NSLog(@"viewDidDisappear");
}

//响应点击事件
//默认情况下UIView是接收touch事件的
//如果要获取这个事件 就需要重写touch方法
//当手指触摸到屏幕
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    //交换orangeView和blackView的层级关系
    //1.如何获取这个两个对象
    //a.通过子视图父视图的层级关系来获取
//    UIView *v1 = [self.view.subviews objectAtIndex:0];
//    UIView *v2 = [self.view.subviews objectAtIndex:1];
//
//    [self.view bringSubviewToFront:v1];
    
    //b.通过view的tag属性 每一个控件都一个tag属性 整数 默认是0
    //viewWithTag方法通过tag获取一个子视图
//    UIView *v1 = [self.view viewWithTag:1];
//    [self.view bringSubviewToFront:v1];
    
    //c.添加属性变量
    [self.view bringSubviewToFront:self.orangeView];
}

//手指在屏幕上滑动
- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    //获取手指的触摸位置 点的坐标
    //获取UITouch对象 touhes数组里面只有一个touch对象
    UITouch *touch = [touches anyObject];
    
    //获取touch对象在self.view上触摸点的坐标
    CGPoint touchPoint = [touch locationInView:self.view];
    
    //更改黑色视图的位置 center
    self.blackView.center = touchPoint;
}

//手指离开屏幕
- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{}

//- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
//    //1.创建下一个界面
//    SecondViewController *svc = [[SecondViewController alloc] init];
//
//    //2.推送到下一个界面
//    [self.navigationController pushViewController:svc animated:YES];
//}
@end



















