//
//  main.m
//  1.iOS程序创建
//
//  Created by PengXiaodong on 2018/8/3.
//  Copyright © 2018年 PengXiaodong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

/*
 UIApplicationMain 创建一个应用程序的UI主线程
 iOS程序是一个死循环 只有程序出错或者用户自己强制关闭
 
 */
int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}









