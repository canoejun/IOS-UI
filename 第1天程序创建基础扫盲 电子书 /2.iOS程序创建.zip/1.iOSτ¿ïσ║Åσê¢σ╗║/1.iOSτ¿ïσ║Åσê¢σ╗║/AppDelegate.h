//
//  AppDelegate.h
//  1.iOS程序创建
//
//  Created by PengXiaodong on 2018/8/3.
//  Copyright © 2018年 PengXiaodong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

/*
 一个应用程序必须至少有一个窗口 每个窗口管理一个程序独立的界面
 一个程序可以有多个窗口 但是不建议有多个窗口 通常只有一个窗口
 */
@property (strong, nonatomic) UIWindow *window;


@end








