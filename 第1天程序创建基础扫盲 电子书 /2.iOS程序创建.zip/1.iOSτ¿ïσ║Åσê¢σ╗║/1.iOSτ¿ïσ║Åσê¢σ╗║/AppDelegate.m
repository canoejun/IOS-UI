//
//  AppDelegate.m
//  1.iOS程序创建
//
//  Created by PengXiaodong on 2018/8/3.
//  Copyright © 2018年 PengXiaodong. All rights reserved.
//

#import "AppDelegate.h"
#import "MainViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


//当程序完成硬件加载的工作之后，就会来回调这个方法
//通过这个方法来配置加载哪个界面
//默认 系统会加载Main.storyboard里面的第一个界面作为主界面
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    //定义程序的界面加载 加载哪个界面
    //配置界面的加载
    //1.创建一个窗口
    self.window = [[UIWindow alloc] init];
    
    //设置窗口的大小 和屏幕大小一样
    _window.frame = [UIScreen mainScreen].bounds;
    
    //创建主界面
    MainViewController *mainVC = [[MainViewController alloc] init];
    //设置主界面的背景颜色为白色
    mainVC.view.backgroundColor = [UIColor whiteColor];
    
    //创建一个导航栏控制器
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:mainVC];
    
    //将mainVC设置为窗口的root view controller
    _window.rootViewController = nav;
    
    //显示窗口
    [self.window makeKeyAndVisible];
    
    return YES;
}

@end










